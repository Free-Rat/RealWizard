//
//  NavigationManager.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 10/06/2024.
//

import Foundation
import Combine
import SwiftUI

enum SelectionState: Hashable, Codable {
    case casting(CastingMode)
    case presenting(Spell)
}

class NavigationManager: ObservableObject {
    @Published var selectionState: SelectionState? = nil
    @Published var showMenu: Bool = true
    
    @Published var columnVisibility = NavigationSplitViewVisibility.doubleColumn
    
    func deselect() {
        selectionState = nil
    }
    
    func selectCastingSpell() {
        deselect()
        selectionState = .casting(.casting)
    }
    
    func selectCreatingSpell() {
        deselect()
        selectionState = .casting(.creating)
    }
    
    func selectPresent(spell: Spell) {
        deselect()
        selectionState = .presenting(spell)
    }
}
