//
//  MotionManager.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 03/06/2024.
//

import CoreMotion
import Foundation

class MotionManager: ObservableObject {
    private var motionManager = CMMotionManager()
    private let updateInterval = 1.0 / 120.0 // 60 Hz
    
    var accelerometerValues: [CMAcceleration?] = []
    var gyroscopeValues: [CMRotationRate?] = []
    
    func startRecordingSpell() {
        if motionManager.isDeviceMotionAvailable {
            motionManager.deviceMotionUpdateInterval = updateInterval
            motionManager.startDeviceMotionUpdates(to: .main) { [weak self] (data, error) in
                guard let data = data, error == nil else { return }

                self?.accelerometerValues.append(data.userAcceleration)
                self?.gyroscopeValues.append(data.rotationRate)
                print(data.userAcceleration.x, data.userAcceleration.y, data.userAcceleration.z)
//                print(data.rotationRate.x, data.rotationRate.y, data.rotationRate.z)
//                print(data.userAcceleration.x)
            }
        } else {
            print("device motion error")
        }
    }
    
    func stopUpdates() {
        if motionManager.isDeviceMotionActive {
            motionManager.stopDeviceMotionUpdates()
        }
    }
    
    func resetValues() {
        accelerometerValues = []
        gyroscopeValues = []
    }
}
