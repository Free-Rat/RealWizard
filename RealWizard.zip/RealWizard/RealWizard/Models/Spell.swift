//
//  Spell.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 08/06/2024.
//

import Foundation
import CoreMotion

struct Spell: Identifiable, Hashable, Codable {
    var id: Int
    var name: String
    var dmg: Int
    var img: String
    var accelerometerValues: [[Double]]
    var gyroscopeValues: [[Double]]
    
    static var currentID = 0
    
    init(id: Int, name: String, dmg: Int, img: String, accelerometerValues: [CMAcceleration?], gyroscopeValues: [CMRotationRate?]) {
//        Spell.currentID += 1
        self.id = id
        self.name = name
        self.dmg = dmg
        self.img = img
        let convertedValues = SpellsManager.shared.convertMotionValues(accelerometerValues, gyroscopeValues)
        self.accelerometerValues = convertedValues.0
        self.gyroscopeValues = convertedValues.1
    }
    
    init(id: Int, name: String, dmg: Int, img: String, accelerometerValues: [[Double]], gyroscopeValues: [[Double]]) {
        self.id = id
        self.name = name
        self.dmg = dmg
        self.img = img
        self.accelerometerValues = accelerometerValues
        self.gyroscopeValues = gyroscopeValues
    }
}
