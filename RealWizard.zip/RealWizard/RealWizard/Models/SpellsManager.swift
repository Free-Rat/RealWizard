//
//  SpellsManager.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 03/06/2024.
//

import Foundation
import CoreMotion


class SpellsManager: ObservableObject {
    public static var shared: SpellsManager = SpellsManager.init()
    
    @Published var spells:[Spell]
    @Published var motionManager: MotionManager
    @Published var castedSpell: Spell?
    let threshold: Double = 0.75
    
    init() {
        spells = []
        motionManager = MotionManager.init()
    }
    
    func createSpell() -> Spell? {
        let newName: String = "New Spell"
        let newDmg: Int = 0
        let newImg: String = ""
        if motionManager.accelerometerValues.count < 120 {
            return nil
        }
//        let newAccelerometerValues =  motionManager.accelerometerValues
//        let newGyroscopeValues = motionManager.gyroscopeValues
        let (nAccV, nGyroV) = convertMotionValues(motionManager.accelerometerValues, motionManager.gyroscopeValues)
        let newSpell = Spell(id: (spells.last?.id ?? 0) + 1,
                             name: newName,
                             dmg: newDmg,
                             img: newImg,
                             accelerometerValues: nAccV,
                             gyroscopeValues: nGyroV
        )
        return newSpell
    }
    
    func convertMotionValues(_ accelerometerValues: [CMAcceleration?], _ gyroscopeValues: [CMRotationRate?]) -> ([[Double]], [[Double]]) {
        var newAccelerometerValues: [[Double]] = []
        var newGyroscopeValues: [[Double]] = []
        for value in accelerometerValues {
            newAccelerometerValues.append([(value?.x ?? 0) * 1000, (value?.y ?? 0) * 1000, (value?.z ?? 0) * 1000])
        }
        for value in gyroscopeValues {
            newGyroscopeValues.append([value?.x ?? 0, value?.y ?? 0, value?.z ?? 0])
        }
        newAccelerometerValues = cleanData(data: newAccelerometerValues)
        newGyroscopeValues = cleanData(data: newGyroscopeValues)
        return (newAccelerometerValues, newGyroscopeValues)
    }
    
    // Function to calculate the dot product of two vectors
    func dotProduct(_ vector1: [Double], _ vector2: [Double]) -> Double {
        var result = 0.0
        for i in 0..<vector1.count {
            result += vector1[i] * vector2[i]
        }
        return result
    }

    // Function to calculate the magnitude (norm) of a vector
    func magnitude(_ vector: [Double]) -> Double {
        return sqrt(dotProduct(vector, vector))
    }

    // Function to pad a vector with zeros to a specified length
    func padVector(_ vector: [Double], toLength length: Int) -> [Double] {
        var paddedVector = vector
        while paddedVector.count < length {
            paddedVector.append(0.0)
        }
        return paddedVector
    }

    // Function to calculate cosine similarity between two vectors
    func cosineSimilarity(_ vector1: [Double], _ vector2: [Double]) -> Double {
        let maxLength = max(vector1.count, vector2.count)
        let paddedVector1 = padVector(vector1, toLength: maxLength)
        let paddedVector2 = padVector(vector2, toLength: maxLength)
        
        let dotProd = dotProduct(paddedVector1, paddedVector2)
        let magnitude1 = magnitude(paddedVector1)
        let magnitude2 = magnitude(paddedVector2)
        
        if magnitude1 == 0.0 || magnitude2 == 0.0 {
            return 0.0 // To handle the case where one of the vectors is zero
        }
        
        return dotProd / (magnitude1 * magnitude2)
    }
    
    func padMatrix(_ mat: [[Double]], toLenght lenght: Int) -> [[Double]] {
        var paddedMatrix = mat
        while paddedMatrix.count < lenght {
            paddedMatrix.append([0.0, 0.0, 0.0])
        }
        return paddedMatrix
    }
    
    func compareMatixies(_ mat1: [[Double]],_ mat2: [[Double]], method:(_ vector1: [Double], _ vector2: [Double]) -> Double ) -> Double {
        var similarityArray: [Double] = []
        let maxLength = max(mat1.count, mat2.count)
        let minLength = min(mat1.count, mat2.count)
        let paddedMatrix1 = normalize(data: padMatrix(mat1, toLenght: maxLength))
        let paddedMatrix2 = normalize(data: padMatrix(mat2, toLenght: maxLength))
        var rowsSimilarity: [Double] = []
        for i in 0..<minLength {
            rowsSimilarity.append(method(paddedMatrix1[i], paddedMatrix2[i]))
        }
        similarityArray.append(rowsSimilarity.reduce(0, +)/Double(rowsSimilarity.count))
//        let rowCount = paddedMatrix1.count
        let colCount = paddedMatrix1[0].count
        for col in 0..<colCount {
            let column1 = paddedMatrix1.map { $0[col] * 1000}
            let column2 = paddedMatrix2.map { $0[col] * 1000}
            similarityArray.append(method(column1, column2))
        }
        return similarityArray.reduce(0, +)/Double(similarityArray.count)
    }

    func compareSpells(_ spell1: Spell, _ spell2: Spell) -> Bool {
        let accelerationSimilarity = compareMatixies(spell1.accelerometerValues, spell2.accelerometerValues, method: cosineSimilarity(_:_:))
        print(accelerationSimilarity)
//        let rotationSimilarity = compareMatixies(spell1.gyroscopeValues, spell2.gyroscopeValues, method: cosineSimilarity(_:_:))
//        print(rotationSimilarity)
        return accelerationSimilarity >= threshold
    }
    
    func findMostSimilarSpell(_ spell: Spell) -> Spell? {
        var bestSpell: Spell?
        var currMax: Double = threshold
        for colSpell in spells {
            let res = compareMatixies(spell.accelerometerValues, colSpell.accelerometerValues , method: cosineSimilarity(_:_:))
            if currMax < res {
                currMax = res
                bestSpell = colSpell
                
                print(bestSpell!.name)
                print(currMax)
            }
        }
        return bestSpell
    }
    
    // Helper function to normalize data
    func normalize(data: [[Double]]) -> [[Double]] {
        let rowCount = data.count
        let colCount = data[0].count
        var normalizedData = data
        
        for col in 0..<colCount {
            let column = data.map { $0[col] }
            let mean = column.reduce(0, +) / Double(rowCount)
            let variance = column.map { ($0 - mean) * ($0 - mean) }.reduce(0, +) / Double(rowCount)
            let stddev = sqrt(variance)
            
            for row in 0..<rowCount {
                normalizedData[row][col] = (data[row][col] - mean) / stddev
            }
        }
        return normalizedData
    }
    
    // Helper function to filter out the top 5% and bottom 5% values from a list
    func filterOutliers(data: [Double]) -> [Double] {
        let sortedData = data.sorted()
        let count = data.count
        let lowerBound = Int(Double(count) * 0.05)
        let upperBound = Int(Double(count) * 0.90)
        
        return Array(sortedData[lowerBound..<upperBound])
    }

    // Helper function to process each axis separately and filter out the outliers
    func cleanData(data: [[Double]]) -> [[Double]] {
        let transposedData = transpose(data: data)
        
        let filteredX = filterOutliers(data: transposedData[0])
        let filteredY = filterOutliers(data: transposedData[1])
        let filteredZ = filterOutliers(data: transposedData[2])
        
        // Transpose back to the original format
        let cleanedData = transpose(data: [filteredX, filteredY, filteredZ])
        
        return cleanedData
    }

    // Helper function to transpose a 2D array
    func transpose(data: [[Double]]) -> [[Double]] {
        guard let firstRow = data.first else { return [] }
        
        var transposed = Array(repeating: [Double](), count: firstRow.count)
        
        for row in data {
            for (index, element) in row.enumerated() {
                transposed[index].append(element)
            }
        }
        return transposed
    }

    // Helper function to extract features (mean and variance)
    func extractFeatures(data: [[Double]]) -> [Double] {
        let rowCount = data.count
        let colCount = data[0].count
        var features: [Double] = []
        
        for col in 0..<colCount {
            let column = data.map { $0[col] }
            let mean = column.reduce(0, +) / Double(rowCount)
            let variance = column.map { ($0 - mean) * ($0 - mean) }.reduce(0, +) / Double(rowCount)
            
            features.append(mean)
            features.append(variance)
        }
        return features
    }
    
//
//    func calculateMeanAndStdDev(_ differences: [Double]) -> (mean: Double, stdDev: Double) {
//        let mean = differences.reduce(0, +) / Double(differences.count)
//        let variance = differences.map { pow($0 - mean, 2) }.reduce(0, +) / Double(differences.count)
//        let stdDev = sqrt(variance)
//        return (mean, stdDev)
//    }
//
//    func compareSpells(_ first: Spell, _ second: Spell) -> Bool {
//        let accelerometerThreshold: Double = 0.08
//        let gyroscopeThreshold: Double = 2.0
//        
//        let lengthFirst = first.accelerometerValues.count
//        let lengthSecond = second.accelerometerValues.count
//        
//        if lengthFirst == 0 || lengthSecond == 0 {
//            print("Error: One of the spells has empty accelerometerValues")
//            return false
//        }
//        
//        let minSize = min(lengthFirst, lengthSecond)
//        
////        if Double(min(lengthFirst, lengthSecond)) / Double(max(lengthFirst, lengthSecond)) < 0.8 {
////            print("spell was to short")
////            return false
////        }
//        
//        var accelerometerDiffs: [Double] = []
//        var gyroscopeDiffs: [Double] = []
//        
//        for i in 0..<minSize {
//            let accDiffs = calculateDifferences(first.accelerometerValues[i], second.accelerometerValues[i])
//            let gyrDiffs = calculateDifferences(first.gyroscopeValues[i], second.gyroscopeValues[i])
//            
//            accelerometerDiffs.append(contentsOf: accDiffs)
//            gyroscopeDiffs.append(contentsOf: gyrDiffs)
//        }
//        
//        let (accMean, accStdDev) = calculateMeanAndStdDev(accelerometerDiffs)
//        let (gyrMean, gyrStdDev) = calculateMeanAndStdDev(gyroscopeDiffs)
//        
//        print("Accelerometer - Mean: \(accMean), StdDev: \(accStdDev)")
//        print("Gyroscope - Mean: \(gyrMean), StdDev: \(gyrStdDev)")
//        
//        return accMean <= accelerometerThreshold && accStdDev <= accelerometerThreshold &&
//               gyrMean <= gyroscopeThreshold && gyrStdDev <= gyroscopeThreshold
//    }
//
//    func calculateDifferences(_ first: [Double], _ second: [Double]) -> [Double] {
//        return zip(first, second).map { abs($0 - $1) }
//    }
//    
//    func comperSpells(_ first: Spell, _ second: Spell) -> Bool {
//        let thresholdOfAccelerometer: Double = 0.05
//        let thresholdOfGyroscope: Double = 2
//        
//        let lenghtFirst = first.accelerometerValues.count
//        let lenghtSecond = second.accelerometerValues.count
//        
//        print("first. : \(first.accelerometerValues.count)")
//        print("second. : \(second.accelerometerValues.count)")
//        let minSize = min(first.accelerometerValues.count, second.accelerometerValues.count)
//        print("min Size: \(minSize)")
//        
//        if Double(min(lenghtFirst,lenghtSecond))/Double(max(lenghtFirst,lenghtSecond)) < 0.8 {
//            return false
//        }
//        
//        if minSize == 0 {
//            print("Error: Passed empty psell accelerometrValues")
//            return false
//        }
//        
//        var similarityCouter: Double = 0
//        
//        for i in 0...minSize - 1 {
//            let xAccDiff: Double = abs(first.accelerometerValues[i][0] - second.accelerometerValues[i][0])
//            print("xAD", xAccDiff, ": ", first.accelerometerValues[i][0], "  —  ", second.accelerometerValues[i][0])
//            
//            let yAccDiff: Double = abs(first.accelerometerValues[i][1] - second.accelerometerValues[i][1])
//            let zAccDiff: Double = abs(first.accelerometerValues[i][2] - second.accelerometerValues[i][2])
//            
//            
//            let xGyrDiff: Double = abs(first.gyroscopeValues[i][0] - second.gyroscopeValues[i][0])
//            print("xGD", xGyrDiff, ": ", first.gyroscopeValues[i][0], "  —  ", second.gyroscopeValues[i][0])
//            
//            let yGyrDiff: Double = abs(first.gyroscopeValues[i][1] - second.gyroscopeValues[i][1])
//            let zGyrDiff: Double = abs(first.gyroscopeValues[i][2] - second.gyroscopeValues[i][2])
//            
//            let arrayOfAccDiffs: [Double] = [xAccDiff, yAccDiff, zAccDiff]
//            let arrayOfGyrDiff: [Double] = [xGyrDiff, yGyrDiff, zGyrDiff]
//            
////            print(i, " : ", arrayOfAccDiffs)
////            print(i, " : ", arrayOfGyrDiff)
//            var accepetedDiffsCounter: Int = 0
//            
//            for diff in arrayOfAccDiffs {
//                if diff <= thresholdOfAccelerometer {
//                    accepetedDiffsCounter += 1
//                }
//            }
//            for diff in arrayOfGyrDiff {
//                if diff <= thresholdOfGyroscope {
//                    accepetedDiffsCounter += 1
//                }
//            }
//            if accepetedDiffsCounter >= 4 {
//                similarityCouter += 1
//            }
//            print(accepetedDiffsCounter)
//        }
//        
//        print("simiralrity procetage  ", similarityCouter/Double(minSize) )
//        
//        if similarityCouter/Double(minSize) >= 0.8 {
//            return true
//        }
//        
//        return false;
//    }
    
}
