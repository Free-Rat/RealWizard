//
//  DataBaseManager.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 08/06/2024.
//

import Foundation
import SQLite3

class DataBaseManager {
    public static var shared: DataBaseManager = DataBaseManager.init()
    
    let dbPath: String = "myDb.sqlite"
    var db: OpaquePointer?

    init() {
        db = openDatabase()
        createSpellsTable()
    }
    
    func openDatabase() -> OpaquePointer? {
        let filePath = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent(dbPath)
        var db: OpaquePointer?
        if sqlite3_open(filePath.path, &db) != SQLITE_OK {
            debugPrint("can't open database")
            return nil
        } else {
            print("Successfully created connection to database at \(dbPath)")
            return db
        }
    }
    
    func dropTable(_ nameOfTable: String) {
        var db: OpaquePointer?
        let filePath = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent(dbPath)
        
        if sqlite3_open(filePath.path, &db) == SQLITE_OK {
            let dropQuery = "DROP TABLE IF EXISTS \(nameOfTable);"
            
            if sqlite3_exec(db, dropQuery, nil, nil, nil) == SQLITE_OK {
                print("Table '\(nameOfTable)' dropped successfully.")
            } else {
                let errorMessage = String(cString: sqlite3_errmsg(db))
                print("Error dropping table: \(errorMessage)")
            }
            
            sqlite3_close(db)
        } else {
            print("Can't open database.")
        }
    }
    
//    var id: Int
//    var name: String
//    var dmg: Int
//    var img: String
//    var accelerometerValues: [CMAcceleration?]
//    var gyroscopeValues: [CMRotationRate?]
    
    func createSpellsTable() {
        let createTableString = """
        CREATE TABLE IF NOT EXISTS spells(
        id INTEGER PRIMARY KEY,
        name TEXT,
        dmg INTEGER,
        img TEXT,
        accelerometerValues TEXT,
        gyroscopeValues TEXT
        );
        """
        var createTableStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, createTableString, -1, &createTableStatement, nil) == SQLITE_OK {
            if sqlite3_step(createTableStatement) == SQLITE_DONE {
                print("spells table created.")
            } else {
                print("spells table could not be created.")
            }
        } else {
            print("CREATE spells statement could not be prepared.")
        }
        sqlite3_finalize(createTableStatement)
    }
    
    func convert2DArrayToString(array:[[Double]]) -> String {
        let innerSeparator: String = ";"
        let outerSeparator: String = ":"
        
        let stringArray2D = array.map { innerArray in
            innerArray.map { String($0) }.joined(separator: innerSeparator)
        }
        let finalString = stringArray2D.joined(separator: outerSeparator)
        return finalString
    }
    
    func convertStringTo2DArray(string: String ) -> [[Double]]? {
        let innerSeparator: String = ";"
        let outerSeparator: String = ":"
        let rows = string.components(separatedBy: outerSeparator)
        var result: [[Double]] = []
        
        for row in rows {
            let elements = row.components(separatedBy: innerSeparator)
            let doubleElements = elements.compactMap { Double($0) }
            if doubleElements.count != elements.count {
                return nil
            }
            result.append(doubleElements)
        }
        return result
    }

    func insertSpell(spell: Spell) {
        let insertStatementString = """
        INSERT INTO
        spells (id, name, dmg, img, accelerometerValues, gyroscopeValues)
        VALUES ( ?,    ?,   ?,   ?,                   ?,               ?);
        """
//        let accValCopy = spell.accelerometerValues
//        let afterAccValCopy = convertStringTo2DArray(string: convert2DArrayToString(array: accValCopy))
//        print(accValCopy == afterAccValCopy)
//        for i in 0...accValCopy.count - 1 {
//            print(accValCopy[i], afterAccValCopy?[i] ?? "ERR")
//        }
        var insertStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
            sqlite3_bind_int(insertStatement, 1, Int32(spell.id))
            sqlite3_bind_text(insertStatement, 2, (spell.name as NSString).utf8String, -1, nil)
            sqlite3_bind_int(insertStatement, 3, Int32(spell.dmg))
            sqlite3_bind_text(insertStatement, 4, (spell.img as NSString).utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 5, (convert2DArrayToString(array: spell.accelerometerValues) as NSString).utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 6, (convert2DArrayToString(array: spell.gyroscopeValues) as NSString).utf8String, -1, nil)
            if sqlite3_step(insertStatement) == SQLITE_DONE {
//                print("Successfully inserted row of User.")
            } else {
                print("Could not insert row spells.")
            }
        } else {
            print("INSERT statement could not be prepared spells.")
        }
        sqlite3_finalize(insertStatement)
    }

    func readSpells() -> [Spell] {
        let queryStatementString = "SELECT id, name, dmg, img, accelerometerValues, gyroscopeValues FROM spells;"
        var queryStatement: OpaquePointer?
        var spells: [Spell] = []
        if sqlite3_prepare_v2(db, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            while sqlite3_step(queryStatement) == SQLITE_ROW {
                let id = Int(sqlite3_column_int(queryStatement, 0))
                let name = String(describing: String(cString: sqlite3_column_text(queryStatement, 1)))
                let dmg = Int(sqlite3_column_int(queryStatement, 2))
                let img = String(describing: String(cString: sqlite3_column_text(queryStatement, 3)))
                let accelerometerValues = String(describing: String(cString: sqlite3_column_text(queryStatement, 4)))
                let gyroscopeValues = String(describing: String(cString: sqlite3_column_text(queryStatement, 5)))
                
                var convertedAccelerometerValues = convertStringTo2DArray(string: accelerometerValues)
                var convertedGyroscopeValues = convertStringTo2DArray(string: gyroscopeValues)
                
                if convertedAccelerometerValues == nil {
                    convertedAccelerometerValues = []
                }
                if convertedGyroscopeValues == nil {
                    convertedGyroscopeValues = []
                }
                spells.append(Spell.init(id: Int(id),
                                         name: name,
                                         dmg: dmg,
                                         img: img,
                                         accelerometerValues: convertedAccelerometerValues! ,
                                         gyroscopeValues: convertedGyroscopeValues!)
                )
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        sqlite3_finalize(queryStatement)
        return spells
    }
    
    func updateSpell(spell: Spell) {
        let updateStatementString = """
        UPDATE spells
        SET name = ?, dmg = ?, img = ?, accelerometerValues = ?, gyroscopeValues = ?
        WHERE id = ?;
        """
        var updateStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, updateStatementString, -1, &updateStatement, nil) == SQLITE_OK {
            sqlite3_bind_text(updateStatement, 1, (spell.name as NSString).utf8String, -1, nil)
            sqlite3_bind_int(updateStatement, 2, Int32(spell.dmg))
            sqlite3_bind_text(updateStatement, 3, (spell.img as NSString).utf8String, -1, nil)
            sqlite3_bind_text(updateStatement, 4, (convert2DArrayToString(array: spell.accelerometerValues) as NSString).utf8String, -1, nil)
            sqlite3_bind_text(updateStatement, 5, (convert2DArrayToString(array: spell.gyroscopeValues) as NSString).utf8String, -1, nil)
            sqlite3_bind_int(updateStatement, 6, Int32(spell.id))

            if sqlite3_step(updateStatement) == SQLITE_DONE {
                print("Successfully updated row.")
            } else {
                print("Could not update row.")
            }
        } else {
            print("UPDATE statement could not be prepared.")
        }
        sqlite3_finalize(updateStatement)
    }


    func deleteSpellByID(id: Int) {
        let deleteStatementStirng = "DELETE FROM spells WHERE Id = ?;"
        var deleteStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, deleteStatementStirng, -1, &deleteStatement, nil) == SQLITE_OK {
            sqlite3_bind_int(deleteStatement, 1, Int32(id))
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Successfully deleted row. spell")
            } else {
                print("Could not delete row. spell")
            }
        } else {
            print("DELETE statement could not be prepared spell")
        }
        sqlite3_finalize(deleteStatement)
    }

    func deleteAllRows(table: String) {
        let deleteStatementString = "DELETE FROM \(table);"
        var deleteStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, deleteStatementString, -1, &deleteStatement, nil) == SQLITE_OK {
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Successfully deleted all rowns from \(table)")
            } else {
                print("Could not delete all rowns from \(table)")
            }
        } else {
            print("DELETE statement could not be prepared")
        }
        sqlite3_finalize(deleteStatement)
    }
}
