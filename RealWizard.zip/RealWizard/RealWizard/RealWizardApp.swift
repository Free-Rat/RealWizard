//
//  RealWizardApp.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 02/06/2024.
//

import SwiftUI

//var SharedSpellsManager: SpellsManager = SpellsManager.init()

@main
struct RealWizardApp: App {
    var body: some Scene {
        WindowGroup {
            SplitView()
        }
    }
}
