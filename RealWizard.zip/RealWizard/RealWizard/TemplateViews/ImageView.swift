//
//  File.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 08/06/2024.
//

import Foundation
import SwiftUI

struct ImageView: View {
    let imageUrlString: String

    var body: some View {
        if let url = URL(string: imageUrlString) {
            AsyncImage(url: url) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } placeholder: {
                ProgressView()
            }
            .frame(height: 350)
        } else {
//            Text("Invalid URL")
            Image(systemName: "wand.and.stars.inverse")
                .frame(height: 350)
       }
    }
}
