//
//  SpellView.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 03/06/2024.
//

import Foundation
import SwiftUI

struct SpellDetailView: View {
//    @Binding var spell: Spell
//    var spell: Spell
    @State var spell: Spell
    @State var nameString: String = ""
    @State var damageString: String = ""
    @State var imgURLString: String = ""
    @State var isEditable: Bool = false
    @Environment(\.dismiss) var dismiss
    var body: some View {
        VStack {
            if !isEditable {
                ImageView(imageUrlString: imgURLString)
                    .padding(20)
                Text(nameString)
                Text("Damage: \(damageString)")
                Spacer()
            } else {
                textFieldView(title: "Name", binding: $nameString)
                textFieldView(title: "Damage", binding: $damageString)
                textFieldView(title: "url", binding: $imgURLString)
            }
        }
        .onAppear(perform: {
            damageString = String(spell.dmg)
            nameString = spell.name
            imgURLString = spell.img
        })
        .navigationTitle(nameString)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    if isEditable {
                        update()
                    }
                    isEditable.toggle()
                }) {
                    Text(Image(systemName: "pencil"))
                }
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    delete()
                }, label: {
                    Image(systemName: "trash")
                })
            }
        }
    }
    
    func update() {
        var spellCopy = spell
        spellCopy.name = nameString
        spellCopy.dmg = Int(damageString) ?? 69
        spellCopy.img = imgURLString
        DataBaseManager.shared.updateSpell(spell: spellCopy)
    }
    
    func delete() {
        SpellsManager.shared.spells.removeAll { spellFromCollection in
            spellFromCollection.id == spell.id - 1
        }
        print(spell.id)
        DataBaseManager.shared.deleteSpellByID(id: spell.id)
        dismiss()
    }
    
    func textFieldView(title: String, binding: Binding<String>) -> some View {
        HStack {
            Spacer(minLength: 100)
            Text(title + ": ")
            TextField(" Change " + title + " of Spell ", text: binding )
//                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding()
            Spacer(minLength: 100)
        }
    }
}
