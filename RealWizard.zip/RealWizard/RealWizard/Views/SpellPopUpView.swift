//
//  SpellPopUpView.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 09/06/2024.
//

import Foundation
import SwiftUI

struct SpellPopUpView: View {
    let spell: Spell
    @Binding var isShowing: Bool
    var body: some View {
        VStack {
            Spacer()
            ImageView(imageUrlString: spell.img)
                .padding(20)
            
            Text(spell.name)
            
            Spacer()
            
            Button(action: {
                withAnimation {
                    self.isShowing = false
                }
            }) {
                Text("Close")
                    .foregroundColor(.blue)
                    .padding(5)
                    .background(Color(.systemGray4))
                    .cornerRadius(10)
                    .padding(15)
            }
        }
        .frame(width: 500, height: 550)
        .background(Color(.systemGray6))
        .cornerRadius(40)
//        .shadow(radius: 10)
        .overlay(
            RoundedRectangle(cornerRadius: 40)
                .stroke(Color.gray, lineWidth: 0)
        )
    }
}
