//
//  SplitView.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 03/06/2024.
//

import Foundation
import SwiftUI
import Combine


struct SplitView: View {
    @State private var preferredColumn = NavigationSplitViewColumn.detail
//    @State private var columnVisibility = NavigationSplitViewVisibility.doubleColumn
    @ObservedObject var spellManager = SpellsManager.shared
//    @StateO var selection: SelectionState? = nil
    @StateObject var navigationManager = NavigationManager()
    
    var body: some View {
        NavigationSplitView(columnVisibility: $navigationManager.columnVisibility, preferredCompactColumn: $preferredColumn, sidebar: {
            Sidebar()
        }, detail: {
            StartView()
        })
        .environmentObject(navigationManager)
        .environmentObject(spellManager)
        
    }
}



struct MenuCell<Title: View, Destination: View>: View {
    var destination: () -> Destination
    var title: Title
    var body: some View {
        NavigationLink(destination: destination) {
            title
        }
        .frame(maxWidth: .infinity)
        //        .background(Color(.systemGray5))
        //        .foregroundColor(.blue)
        //        .cornerRadius(10)
    }
}

//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
