//
//  Sidebar.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 10/06/2024.
//

import SwiftUI

struct Sidebar: View {
    
    @EnvironmentObject var spellManager: SpellsManager
    @EnvironmentObject var navigationManager: NavigationManager
    @Environment(\.dismiss) var dismiss

    var body: some View {
            List(selection: $navigationManager.selectionState) {
                
                NavigationLink(value: CastingMode.casting) {
                    Text("Cast Spell")
                }
                .onTapGesture {
                    navigationManager.columnVisibility = .detailOnly
                    navigationManager.selectionState = .casting(.casting)
                }
                
                NavigationLink(value: CastingMode.creating) {
                    Text("Create Spell")
                }
                .onTapGesture {
                    navigationManager.columnVisibility = .detailOnly
                    navigationManager.selectionState = .casting(.creating)
                }
                Section {
                    Text ("Collection")
                        .bold()
                        .font(.title2)
                        .foregroundStyle(Color(.lightGray))
                }
                ForEach($spellManager.spells) { $spell in
                    NavigationLink {
                        DetailSpellView(spell: $spell)
                    } label: {
                        HStack {
                            ThumbnailView(imageUrlString: spell.img)
                            Text(spell.name)
                        }
                    }
                }
            }
            .listStyle(.sidebar)
            .navigationTitle("Menu")
            .onAppear(perform: {
                SpellsManager.shared.spells = DataBaseManager.shared.readSpells()
            })
            .navigationDestination(for: CastingMode.self) { value in
                switch value {
                    case .casting:
                        SpellCast(mode: .casting)
                    case .creating:
                        SpellCast(mode: .creating)
//                    default:
//                        Text("start")
                }
            }
    }
}

//#Preview {
//    Sidebar()
//}
