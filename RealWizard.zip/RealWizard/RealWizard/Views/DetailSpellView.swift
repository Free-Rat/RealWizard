//
//  DetailSpellView.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 10/06/2024.
//

import SwiftUI

struct DetailSpellView: View {
    @Binding var spell: Spell
    @Environment(\.dismiss) var dismiss
    var body: some View {
        VStack {
            ImageView(imageUrlString: spell.img)
                .padding(20)
            Text(spell.name)
                .bold()
                .font(.title2)
            Text("Damage: \(spell.dmg)")
            Spacer()
            //            SpellTextField(title: "Name", binding: $spell.name)
            
            textFieldView(title: "Name", binding: $spell.name)
            textFieldView(title: "Damage", binding: Binding(
                get: { String(spell.dmg) },
                set: { spell.dmg = Int($0) ?? 0 }
            ))
            textFieldView(title: "url", binding: $spell.img)
            Button(action: {
                update()
            }, label: {
                Text("Update")
                    .foregroundColor(.blue)
                    .padding(5)
                    .background(Color(.systemGray4))
                    .cornerRadius(10)
                    .padding(15)
            })
            Spacer()
        }
        .navigationTitle(spell.name)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    delete()
                }, label: {
                    Image(systemName: "trash")
                })
            }
        }
    }
    
    func update() {
        let spellCopy = spell
        print(spellCopy.img)
        DataBaseManager.shared.updateSpell(spell: spellCopy)
    }
    
    func delete() {
        print(spell.id)
        dismiss()
        DataBaseManager.shared.deleteSpellByID(id: spell.id)
        SpellsManager.shared.spells.removeAll { spellFromCollection in
            spellFromCollection.id == spell.id
        }
    }
    
    func textFieldView(title: String, binding: Binding<String>) -> some View {
        HStack {
            Spacer(minLength: 100)
            Text(title + ": ")
            TextField("Change " + title + " of Spell", text: binding)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding()
            Spacer(minLength: 100)
        }
    }
}
//struct SpellTextField: View {
//    let title: String
//    @Binding var binding: Binding<String>
//    var body: some View {
//        HStack {
//            Spacer(minLength: 100)
//            Text(title + ": ")
//            TextField(" Change " + title + " of Spell ", text: binding )
//                .background(Color(.systemGray6))
//                .cornerRadius(8)
//                .padding()
//            Spacer(minLength: 100)
//        }
//    }
//}
