//
//  ContentView.swift
//  MagicPhone
//
//  Created by Tomasz Ławicki on 21/05/2024.
//

import CoreMotion
import SwiftUI

enum CastingMode: String, CaseIterable, Hashable, Codable {
    case casting
    case creating
}

struct SpellCast: View {
    
    @State var bgColor = Color(.systemMint)
    @State var text = ""
    @State var errortext = ""
    
    @State var mode: CastingMode 
    @State private var found: Bool = false
    @State private var foundedSpell: Spell?
    
    @ObservedObject var spellManager = SpellsManager.shared
    @ObservedObject var motionManager = SpellsManager.shared.motionManager

    var body: some View {
        ZStack {
            Color.black
                .onTouchDownUp { pressed in
                    if pressed {
                        errortext = ""
                        motionManager.startRecordingSpell()
                        bgColor = Color(.systemPurple)
                        handleTextChange(pressed: pressed)
                    } else {
                        motionManager.stopUpdates()
                        bgColor = Color(.systemMint)
                        handleTextChange(pressed: pressed)
                        let castedSpell = spellManager.createSpell()
                        guard castedSpell != nil else {
                            errortext = "Your spell should be minimum 1s long"
                            return
                        }
                        if mode == .casting {
                            if let similarSpell = spellManager.findMostSimilarSpell(castedSpell!) {
                                found = true
                                bgColor = Color(.green)
                                foundedSpell = similarSpell
                                print(foundedSpell!.name)
                            }
                        } else if mode == .creating {
                            spellManager.spells.append(castedSpell!)
                            DataBaseManager.shared.insertSpell(spell: castedSpell!)
                        }
                        motionManager.resetValues()
                    }
                }
            VStack {
                Spacer()
                Text(errortext)
                Text(text)
                    .fontWeight(.heavy)
                    .foregroundColor(bgColor)
                    .padding(50)
                    .overlay(
                        RoundedRectangle(cornerRadius: 100)
                            .stroke(bgColor, lineWidth: 5)
                    )
                Spacer()
            }
            if found {
                ZStack {
                    Color.black.opacity(0.4)
                        .edgesIgnoringSafeArea(.all)
                        .onTapGesture {
                            withAnimation {
                                self.found = false
                            }
                        }
                    SpellPopUpView(spell: foundedSpell!, isShowing: $found)
                        .transition(.scale)
                }
            }

        }
        .onAppear(perform: {
            handleTextChange(pressed: false)
            if mode == .casting {
                bgColor = .orange
            }
        })
        .onChange(of: mode) { oldValue, newValue in
            print(newValue)
        }
        
    }
    
    func handleTextChange(pressed: Bool) {
        if pressed {
            switch mode {
                case .casting:
                    text = "Casting a spell"
                case .creating:
                    text = "Creating a spell"
//                default:
//                    text = ""
            }
        }
        else {
            switch mode {
                case .casting:
                    text = "Tap and Hold to Cast a spell"
                case .creating:
                    text = "Tap and Hold to Create a spell"
//                default:
//                    text = ""
            }
        }
    }
}

extension View {
    /// A convenience method for applying `TouchDownUpEventModifier.`
    func onTouchDownUp(pressed: @escaping ((Bool) -> Void)) -> some View {
        self.modifier(TouchDownUpEventModifier(pressed: pressed))
    }
}

struct TouchDownUpEventModifier: ViewModifier {
    /// Keep track of the current dragging state. To avoid using `onChange`, we won't use `GestureState`
    @State var dragged = false

    /// A closure to call when the dragging state changes.
    var pressed: (Bool) -> Void
    func body(content: Content) -> some View {
        content
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in
                        if !dragged {
                            dragged = true
                            pressed(true)
                        }
                    }
                    .onEnded { _ in
                        dragged = false
                        pressed(false)
                    }
            )
    }
}

