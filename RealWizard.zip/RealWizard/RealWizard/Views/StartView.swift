//
//  File.swift
//  RealWizard
//
//  Created by Tomasz Ławicki on 10/06/2024.
//

import Foundation
import SwiftUI

struct StartView: View {
    
    
    @EnvironmentObject var spellManager: SpellsManager
    @EnvironmentObject var navigationManager: NavigationManager
    
    var body: some View {
        switch navigationManager.selectionState {
            case nil:
                VStack {
                    Text("Welcom The Great Wizard")
                        .bold()
                        .font(.title)
                    Text("Your collection has reached \(SpellsManager.shared.spells.count) spells ")
                        .foregroundStyle(Color(.lightGray))
                }
            case .casting(.casting):
                SpellCast(mode: .casting)
            case .casting(.creating):
                SpellCast(mode: .creating)
            default:
                Text("lul")
        }
    }
}

